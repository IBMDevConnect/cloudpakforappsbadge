<< --License--

Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2017

--License--

#### usage####

if [ "$1" == "--h" ] || [ "$1" == "-h" ] || [ "$1" == "--help" ] || [ "$1" == "-help" ]; then
  echo "Welcome to Transformation Advisor Local."
  echo "To install Transformation Advisor Local you need docker and docker-compose installed."
  exit 0
fi



#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"


############################################# MAC ################################################################################

## check if system is a mac

if uname -s | grep 'Darwin' > /dev/null ;
 then

## check if docker running
cmd6=`docker ps 2>&1`

if [[ "$cmd6" =~ "connect" ]]
          then
           echo "Docker Installed but not running. Please start docker and re-run the script."
           exit
fi

## check docker running
cmd8=`which docker 2>&1`


if [  -z "$cmd8" ] || [[  $cmd8 =~ "no docker in" ]]
          then
           echo ""
           echo "Docker not installed. Please install docker and re-run the script."
           echo "https://docs.docker.com/install/"
           echo ""
           exit
fi


## check if docker compose is installed
cmd7=`which docker-compose  2>&1`


if [  -z "$cmd7" ] || [[ $cmd7 =~ "no docker-compose in" ]]
          then
           echo ""
           echo "Docker Compose not installed. Please install docker-compose and re-run the script."
           echo "https://docs.docker.com/compose/install/"
           echo ""
           exit
fi


cmd3=`docker images | grep transformation-advisor-server | awk '{print $1}'`
cmd4=`docker images | grep transformation-advisor-ui | awk '{print $1}'`
cmd5=`docker images | grep transformation-advisor-db | awk '{print $1}'`


host_to_find=$(ifconfig | grep -Fv -- "-->" | grep "inet " | grep -E -o "([0-9]{1,3}[\.]){3}[0-9]{1,3}" | grep -Fv 127 | grep -Fv 255 | grep -Fv 0.0.0.0)

 if [[   -z $host_to_find && ( -z $cmd3 || -z $cmd4 || -z $cmd5 ) ]];

   then
     echo "Status"
     echo "------------------------------------------------------------------------------------------------------"
     echo "Unable to detect a Public IP Address and not all Transformation Advisor docker images are pulled."
   #  echo "Please connect to a Public IP address to continue."
     echo ""
     echo ""


     echo "

     1) Working in an Air Gapped Environment.
     2) Quit."

     read n
     case $n in
       1) ./scripts/fileImages.sh ;;
       2) exit ;;

    esac
    exit

   fi


## get IP Address of mac

##ip of mac
host_to_find=$(ifconfig | grep -Fv -- "-->" | grep "inet " | grep -E -o "([0-9]{1,3}[\.]){3}[0-9]{1,3}" | grep -Fv 127 | grep -Fv 255 | grep -Fv 0.0.0.0)
host_to_find_array=( $host_to_find)
#sort array
host_to_find_array=( $(printf "%s\n" ${host_to_find_array[@]} | sort -r ) )


## get ID of container
server_ta=`docker ps -a | grep transformation-advisor-server | awk '{print $1}'`


ta_ui_host=""
new_ta_ui_host=""
## check if TA is running
server_ta_running=`docker ps | grep transformation-advisor-server | awk '{print $1}'`


if [[ -n $server_ta_running ]]; then # means TA is running
    ######ta_ui_host=`docker exec -it $server_ta sh -c "env | grep TA_UI_HOST" | awk -F // '{print $2}'`
         ta_ui_host=`docker exec -it $server_ta sh -c "env | grep TA_PUBLIC_ACCESSIBLE"  | awk -F // '{print $2}' | awk -F : '{print $1}'`
    new_ta_ui_host="${ta_ui_host//[[:space:]]/}"
fi

## check if images are pulled
cmd3=`docker images | grep transformation-advisor-server | awk '{print $1}'`
cmd4=`docker images | grep transformation-advisor-ui | awk '{print $1}'`
cmd5=`docker images | grep transformation-advisor-db | awk '{print $1}'`


if [ -e ./.license_accepted ]
then

   if [[ -z $cmd3 ]] && [[ -z $cmd4 ]] && [[ -z $cmd5 ]];
   then
     echo "Status"
     echo "------------------------------------------------------------------------------------------------------"
     echo "Transformation Advisor docker images are not pulled even though there is a license file. Please remove the
     license and re-run the script. rm -rf <install_dir>/.license_accepted"
     exit
   fi

    if [[  ( ! -z $cmd3 && ! -z $cmd4 && -z $cmd5 )  ||  ( ! -z $cmd3  &&  -z $cmd4 &&  -z $cmd5 )  ||  ( ! -z $cmd3  && -z $cmd4 && ! -z $cmd5 )
    ||  ( -z $cmd3  && ! -z $cmd4 && ! -z $cmd5 ) || ( -z $cmd3 &&  -z $cmd4 && ! -z $cmd5 )  || ( -z $cmd3 && ! -z $cmd4 && -z $cmd5 ) ]];
   then
     echo "Status"
     echo "------------------------------------------------------------------------------------------------------"
     echo "Not all Transformation Advisor docker images are pulled."
     echo "Select option 1 to install Transformation Advisor."
     echo ""
     echo ""
echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

echo "

1) Install Transformation Advisor.
2) Quit."

     read n
     case $n in
       1) echo "Installing Transformation Advisor..." ; ./scripts/installTALocal.sh ;;
       2) exit ;;

    esac
    exit

   fi



   if [[ (-n $server_ta_running && (${host_to_find_array[0]} != $new_ta_ui_host)) || !(-n $server_ta_running) ]]; then
     echo -n "Host mismatch...correcting......."

      ./scripts/stopBeforeInstall.sh
      ./scripts/installTALocalMismatch.sh
      #./scripts/renameDockerName.sh
     else
        ./scripts/launchTransformationAdvisor.sh
        exit
   fi
fi

if [ ! -e ./.license_accepted ]
then

 more ./LICENSE

echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

echo "

1) I have read and agreed to the license agreements
2) Don't accept the license agreements"

  read n
  case $n in
    1) touch ./.license_accepted ; ./scripts/launchTransformationAdvisor.sh ;;
    2) exit

  esac
  exit
fi


################################################## END OF MAC ########################################################################################################
else


## check docker
cmd6=`docker ps 2>&1`

if [[ "$cmd6" =~ "connect" ]]
          then
           echo "Docker Installed but not running. Please start docker and re-run the script."
           exit
fi

## check docker running
cmd8=`which docker 2>&1`


if [  -z "$cmd8" ] || [[ ! $cmd8 =~ "/usr/bin/docker" ]] || [[ ! $cmd8 =~ "/bin/docker" ]]
          then
           echo ""
           echo "Docker not installed. Please install docker and re-run the script."
           echo "https://docs.docker.com/install/"
           echo ""
           exit
fi


## check docker compose
cmd7=`which docker-compose  2>&1`


if [  -z "$cmd7" ] || [[ $cmd7 =~ "no docker-compose in" ]]
          then
           echo ""
           echo "Docker Compose not installed. Please install docker-compose and re-run the script."
           echo "https://docs.docker.com/compose/install/"
           echo ""
           exit
fi



cmd3=`docker images | grep transformation-advisor-server | awk '{print $1}'`
cmd4=`docker images | grep transformation-advisor-ui | awk '{print $1}'`
cmd5=`docker images | grep transformation-advisor-db | awk '{print $1}'`


if [ -e ./.license_accepted ]
then

   if [[ -z $cmd3 ]] && [[ -z $cmd4 ]] && [[ -z $cmd5 ]];
   then
     echo "Status"
     echo "------------------------------------------------------------------------------------------------------"
     echo "Transformation Advisor docker images are not pulled even though there is a license file. Please remove the
     license and re-run the script. rm -rf <install_dir>/.license_accepted"
     exit
   fi

   if [[  ( ! -z $cmd3 && ! -z $cmd4 && -z $cmd5 )  ||  ( ! -z $cmd3  &&  -z $cmd4 &&  -z $cmd5 )  ||  ( ! -z $cmd3  && -z $cmd4 && ! -z $cmd5 )
    ||  ( -z $cmd3  && ! -z $cmd4 && ! -z $cmd5 ) || ( -z $cmd3 &&  -z $cmd4 && ! -z $cmd5 )  || ( -z $cmd3 && ! -z $cmd4 && -z $cmd5 ) ]];
   then
     echo "Status"
     echo "------------------------------------------------------------------------------------------------------"
     echo "Not all Transformation Advisor docker images are pulled."
     echo "Select option 1 to install Transformation Advisor."
     echo ""
     echo ""
echo "--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

echo "

1) Install Transformation Advisor.
2) Quit."

     read n
     case $n in
       1) echo "Installing Transformation Advisor..." ; ./scripts/installTALocal.sh ;;
       2) exit ;;

    esac
    exit

   fi


else
  more ./LICENSE

echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

echo "

1) I have read and agreed to the license agreements
2) Don't accept the license agreements"

  read n
  case $n in
    1) touch ./.license_accepted ; ./scripts/launchTransformationAdvisor.sh ;;
    2) exit

  esac
  exit
fi


if [ -e ./.license_accepted ]
then
     ./scripts/launchTransformationAdvisor.sh ;


fi
fi
