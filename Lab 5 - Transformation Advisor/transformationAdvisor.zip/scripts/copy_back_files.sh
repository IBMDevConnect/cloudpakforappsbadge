<< --License--

Licensed Materials - Property of IBM
(C) Copyright IBM Corporation 2017

--License--

cp ./.env_orig ./.env
